# Dukan Saathi

Dukandaar ke liye tarazu helper app (Kotlin, Android).

- ₹ se Gram: rate/KG + ₹ amount -> kitne gram dena hai
- Gram se ₹: rate/KG + gram -> kitne ₹ hue
- Calculator (+ − × ÷ %)
- Bill: kai samaan jodo, total dekho, share karo
- About page: app + developer (SSR - Saksham Singh Rajput)

## GitHub pe APK banana
1. Is poore folder ko ek naye GitHub repo me push karo (branch `main`).
2. Repo ke **Actions** tab me "Build Dukan Saathi APK" khud chalega
   (ya "Run workflow" button dabao).
3. Build khatam hone pe run kholo -> neeche **Artifacts** -> `DukanSaathi-debug-apk` download karo.
4. Zip me se `app-debug.apk` nikalo aur phone me install karo.

Gradle wrapper ki zarurat nahi - workflow khud Gradle 8.7 + Java 17 setup karta hai.
Android Studio me khologe to usse bhi chalega (Gradle sync hone do).
