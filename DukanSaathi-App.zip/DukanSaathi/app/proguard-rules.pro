# Dukan Saathi - no special rules needed
