package com.ssr.dukansaathi

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.ssr.dukansaathi.databinding.ActivityMainBinding
import java.math.BigDecimal
import java.math.RoundingMode

data class BillItem(val name: String, val grams: Double, val price: Double)

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var currentSection: View? = null
    private val bill = mutableListOf<BillItem>()

    // ---- calculator state ----
    private var cur = "0"
    private var stored: Double? = null
    private var op: String? = null
    private var startNew = false
    private var justOp = false
    private val digitKeys = setOf("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "00")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        currentSection = b.sectionGram

        setupNav()
        setupGram()
        setupPaisa()
        setupCalc()
        setupBill()
    }

    // =====================================================================
    // Navigation + smooth section switching
    // =====================================================================
    private fun setupNav() {
        b.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_gram -> showSection(b.sectionGram)
                R.id.nav_daam -> showSection(b.sectionPaisa)
                R.id.nav_calc -> showSection(b.sectionCalc)
                R.id.nav_bill -> showSection(b.sectionBill)
                R.id.nav_about -> showSection(b.sectionAbout)
            }
            true
        }
    }

    private fun showSection(target: View) {
        val old = currentSection
        if (old == target) return
        currentSection = target

        old?.animate()?.alpha(0f)?.setStartDelay(0)?.setDuration(120)?.withEndAction {
            if (currentSection != old) old?.visibility = View.GONE
        }?.start()

        target.alpha = 0f
        target.translationY = 40f
        target.visibility = View.VISIBLE
        target.animate().alpha(1f).translationY(0f).setStartDelay(100).setDuration(260).start()
    }

    // =====================================================================
    // Section 1: Rupaye -> Gram
    // =====================================================================
    private fun setupGram() {
        b.etRateG.onChange { updateGram() }
        b.etAmountG.onChange { updateGram() }

        addQuick(
            b.quickAmountRow,
            listOf("₹5" to "5", "₹10" to "10", "₹20" to "20", "₹50" to "50", "₹100" to "100", "₹200" to "200")
        ) { v ->
            b.etAmountG.setText(v)
            b.etAmountG.setSelection(b.etAmountG.text?.length ?: 0)
        }

        b.btnAddBillG.pressEffect()
        b.btnAddBillG.setOnClickListener {
            val rate = b.etRateG.num()
            val amt = b.etAmountG.num()
            if (rate == null || amt == null || rate <= 0 || amt <= 0) {
                toast("Pehle rate aur ₹ daalo")
                return@setOnClickListener
            }
            addToBill("", amt / rate * 1000.0, amt)
        }
    }

    private fun updateGram() {
        val rate = b.etRateG.num()
        val amt = b.etAmountG.num()
        if (rate == null || amt == null || rate <= 0) {
            b.tvResultG.text = "—"
            b.tvResultGSub.text = "Rate aur ₹ daalo"
            return
        }
        val grams = amt / rate * 1000.0
        b.tvResultG.text = "${fmt(grams, 1)} gram"
        b.tvResultGSub.text = "= ${fmt(grams / 1000.0, 3)} KG\n₹${fmt(amt, 2)} @ ₹${fmt(rate, 2)}/KG"
        pop(b.tvResultG)
    }

    // =====================================================================
    // Section 2: Gram -> Rupaye
    // =====================================================================
    private fun setupPaisa() {
        b.etRateP.onChange { updatePaisa() }
        b.etGramP.onChange { updatePaisa() }

        addQuick(
            b.quickGramRow,
            listOf("50 g" to "50", "100 g" to "100", "250 g" to "250", "500 g" to "500", "1 KG" to "1000")
        ) { v ->
            b.etGramP.setText(v)
            b.etGramP.setSelection(b.etGramP.text?.length ?: 0)
        }

        b.btnAddBillP.pressEffect()
        b.btnAddBillP.setOnClickListener {
            val rate = b.etRateP.num()
            val g = b.etGramP.num()
            if (rate == null || g == null || rate <= 0 || g <= 0) {
                toast("Pehle rate aur gram daalo")
                return@setOnClickListener
            }
            addToBill(b.etItemP.text.toString().trim(), g, rate * g / 1000.0)
        }
    }

    private fun updatePaisa() {
        val rate = b.etRateP.num()
        val g = b.etGramP.num()
        if (rate == null || g == null || rate <= 0) {
            b.tvResultP.text = "—"
            b.tvResultPSub.text = "Rate aur gram daalo"
            return
        }
        val price = rate * g / 1000.0
        b.tvResultP.text = "₹ ${money(price)}"
        b.tvResultPSub.text = "${fmt(g, 1)} gram @ ₹${fmt(rate, 2)}/KG"
        pop(b.tvResultP)
    }

    // =====================================================================
    // Section 3: Calculator
    // =====================================================================
    private fun setupCalc() {
        val rows = listOf(
            listOf("C", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("00", "0", ".", "=")
        )
        val ops = setOf("÷", "×", "−", "+")

        rows.forEach { labels ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            labels.forEach { label ->
                val btn = MaterialButton(this)
                btn.text = label
                btn.isAllCaps = false
                btn.textSize = 22f
                btn.typeface = Typeface.DEFAULT_BOLD
                btn.cornerRadius = 18.dp()
                btn.insetTop = 0
                btn.insetBottom = 0

                val bg: Int
                val fg: Int
                when {
                    label in ops -> { bg = color(R.color.red); fg = color(R.color.white) }
                    label == "=" -> { bg = color(R.color.green); fg = color(R.color.white) }
                    label == "C" -> { bg = color(R.color.yellow); fg = color(R.color.text) }
                    label == "⌫" || label == "%" -> { bg = color(R.color.yellow_light); fg = color(R.color.text) }
                    else -> { bg = color(R.color.white); fg = color(R.color.text) }
                }
                btn.backgroundTintList = ColorStateList.valueOf(bg)
                btn.setTextColor(fg)

                val lp = LinearLayout.LayoutParams(0, 66.dp(), 1f)
                lp.setMargins(4.dp(), 4.dp(), 4.dp(), 4.dp())
                btn.layoutParams = lp
                btn.pressEffect()
                btn.setOnClickListener { onCalcKey(label) }
                row.addView(btn)
            }
            b.calcPad.addView(row)
        }
    }

    private fun onCalcKey(k: String) {
        when {
            k in digitKeys -> {
                if (startNew) { cur = "0"; startNew = false }
                justOp = false
                cur = if (cur == "0") {
                    if (k == "00") "0" else k
                } else if (cur.length < 15) cur + k else cur
            }
            k == "." -> {
                if (startNew) { cur = "0"; startNew = false }
                justOp = false
                if (!cur.contains(".")) cur += "."
            }
            k == "C" -> {
                cur = "0"; stored = null; op = null
                startNew = false; justOp = false
                b.tvExpr.text = ""
            }
            k == "⌫" -> {
                cur = if (startNew || cur.length <= 1) "0" else cur.dropLast(1)
                startNew = false
            }
            k == "%" -> {
                val v = cur.toDoubleOrNull() ?: 0.0
                val s = stored
                val r = if (s != null && (op == "+" || op == "−")) s * v / 100.0 else v / 100.0
                cur = fmt(r, 8)
                startNew = true
            }
            k == "=" -> {
                val s = stored
                val o = op
                if (s != null && o != null) {
                    val v = cur.toDoubleOrNull() ?: 0.0
                    val r = calc(s, o, v)
                    if (r == null) { calcError(); return }
                    b.tvExpr.text = "${fmt(s, 8)} $o ${fmt(v, 8)} ="
                    cur = fmt(r, 8)
                    stored = null; op = null
                    startNew = true; justOp = false
                }
            }
            else -> { // + − × ÷
                val v = cur.toDoubleOrNull() ?: 0.0
                val s = stored
                val o = op
                if (s != null && o != null && !justOp) {
                    val r = calc(s, o, v)
                    if (r == null) { calcError(); return }
                    stored = r
                    cur = fmt(r, 8)
                } else if (s == null) {
                    stored = v
                }
                op = k
                justOp = true
                startNew = true
                b.tvExpr.text = "${fmt(stored ?: v, 8)} $k"
            }
        }
        b.tvDisplay.text = cur
    }

    private fun calc(a: Double, o: String, v: Double): Double? = when (o) {
        "+" -> a + v
        "−" -> a - v
        "×" -> a * v
        "÷" -> if (v == 0.0) null else a / v
        else -> null
    }

    private fun calcError() {
        cur = "0"; stored = null; op = null
        startNew = true; justOp = false
        b.tvExpr.text = ""
        b.tvDisplay.text = "Error"
    }

    // =====================================================================
    // Section 4: Bill
    // =====================================================================
    private fun setupBill() {
        b.btnClearBill.pressEffect()
        b.btnShareBill.pressEffect()

        b.btnClearBill.setOnClickListener {
            bill.clear()
            renderBill()
        }
        b.btnShareBill.setOnClickListener {
            if (bill.isEmpty()) {
                toast("Bill khaali hai")
                return@setOnClickListener
            }
            val sb = StringBuilder("🧾 Bill - Dukan Saathi\n\n")
            bill.forEachIndexed { i, item ->
                sb.append("${i + 1}. ${item.name} - ${fmt(item.grams, 1)} gram - ₹${money(item.price)}\n")
            }
            sb.append("\nKul: ₹${money(bill.sumOf { it.price })}")
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, sb.toString())
            }
            startActivity(Intent.createChooser(intent, "Bill share karo"))
        }
        renderBill()
    }

    private fun addToBill(name: String, grams: Double, price: Double) {
        val finalName = name.ifEmpty { "Samaan ${bill.size + 1}" }
        bill.add(BillItem(finalName, grams, price))
        renderBill()
        toast("Bill me jod diya ✔")
    }

    private fun renderBill() {
        b.billList.removeAllViews()
        b.tvBillEmpty.visibility = if (bill.isEmpty()) View.VISIBLE else View.GONE

        bill.forEachIndexed { i, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 10.dp(), 0, 10.dp())
            }
            val left = TextView(this).apply {
                text = "${item.name}\n${fmt(item.grams, 1)} gram"
                textSize = 15f
                setTextColor(color(R.color.text))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val price = TextView(this).apply {
                text = "₹ ${money(item.price)}"
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(color(R.color.green_dark))
            }
            val del = TextView(this).apply {
                text = "✕"
                textSize = 18f
                setTextColor(color(R.color.red))
                setPadding(20.dp(), 6.dp(), 4.dp(), 6.dp())
                setOnClickListener {
                    bill.removeAt(i)
                    renderBill()
                }
            }
            row.addView(left)
            row.addView(price)
            row.addView(del)
            b.billList.addView(row)
        }

        b.tvBillTotal.text = "₹ ${money(bill.sumOf { it.price })}"
        b.tvBillCount.text = "${bill.size} samaan"
        pop(b.tvBillTotal)
    }

    // =====================================================================
    // Helpers
    // =====================================================================
    private fun addQuick(row: LinearLayout, items: List<Pair<String, String>>, onPick: (String) -> Unit) {
        items.forEach { (label, value) ->
            val btn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            btn.text = label
            btn.isAllCaps = false
            btn.setTextColor(color(R.color.red_dark))
            btn.strokeColor = ColorStateList.valueOf(color(R.color.red))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 44.dp())
            lp.marginEnd = 8.dp()
            btn.layoutParams = lp
            btn.pressEffect()
            btn.setOnClickListener { onPick(value) }
            row.addView(btn)
        }
    }

    private fun EditText.onChange(block: () -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { block() }
        })
    }

    private fun EditText.num(): Double? = text.toString().trim().toDoubleOrNull()

    @SuppressLint("ClickableViewAccessibility")
    private fun View.pressEffect() {
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    private fun pop(v: View) {
        v.scaleX = 0.92f
        v.scaleY = 0.92f
        v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
    }

    private fun color(id: Int): Int = ContextCompat.getColor(this, id)

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    /** Number with up to [dp] decimals, trailing zeros removed. */
    private fun fmt(v: Double, dp: Int): String {
        if (v.isNaN() || v.isInfinite()) return "0"
        return BigDecimal.valueOf(v).setScale(dp, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    }

    /** Money always with 2 decimals. */
    private fun money(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "0.00"
        return BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP).toPlainString()
    }
}
